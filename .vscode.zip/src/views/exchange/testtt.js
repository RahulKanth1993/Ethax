export async function useAllCommonPairs() {

    return;
}