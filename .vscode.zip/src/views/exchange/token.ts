import { ChainId, Token } from '@uniswap/sdk'

const { MAINNET, GÖRLI } = ChainId

export const mainnetTokens = {
    
}

  export const GÖRLITokens = {
    
  }